const api = window.rav;
const $ = (s, r = document) => r.querySelector(s);
const notch = $('#notch');
const store = { get(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d } catch { return d } }, set(k, v) { localStorage.setItem(k, JSON.stringify(v)) } };
const I = {
  prev: '<svg viewBox="0 0 24 24"><path d="M6 6h2v12H6zM9.5 12 18 6v12z"/></svg>',
  next: '<svg viewBox="0 0 24 24"><path d="M16 6h2v12h-2zM14.5 12 6 6v12z"/></svg>',
  play: '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>',
  pause: '<svg viewBox="0 0 24 24"><path d="M7 5h4v14H7zM13 5h4v14h-4z"/></svg>',
  tray: '<svg viewBox="0 0 24 24"><path d="M12 3v10.2l3.6-3.6L17 11l-6 6-6-6 1.4-1.4L11 13.2V3zM4 19h16v2H4z"/></svg>'
};
const ctl = '<div class="ctl"><button data-k="prev">' + I.prev + '</button><button data-k="play" class="pp"></button><button data-k="next">' + I.next + '</button></div>';

/* ---------- pages ---------- */
const PAGES = [
  { n: 'Music', h: `<div class="music"><div class="row"><div class="art"></div><div class="meta"><b class="mT"></b><span class="sub mA"></span></div></div>
     <div class="bar"><span class="tC">0:00</span><div class="track"><i class="fill"></i></div><span class="tL">-0:00</span></div>${ctl}</div><div class="midle"><div class="mdd"><b id="sDay">--</b><span id="sDate"></span></div><div class="mcards"><button data-go="To-do list"><small>To-do</small><b id="sTodo">0/0</b></button><button data-go="Water Reminder"><small>Air minum</small><b id="sWater">0 L</b></button><button data-go="Pomodoro"><small>Fokus</small><b id="sFocus">25:00</b></button></div></div></div>` },
  { n: 'Lyrics', h: `<div class="lyr"><div class="left"><div class="meta"><b class="mT"></b><span class="sub mA"></span></div>${ctl}<div class="bar"><span class="tC">0:00</span><div class="track"><i class="fill"></i></div></div></div>
     <div class="lwin"><div id="lines"></div></div></div>` },
  { n: 'Pomodoro', h: `<div class="pomo"><div class="c"><div class="sub" id="pMode">Focus time</div><div class="time" id="pTime">25:00</div></div>
     <div class="side"><button class="pill" data-m="short">Short Break</button><button class="pill on" data-m="focus">Focus Time</button></div>
     <button class="pbtn" id="pBtn"><svg class="rg" viewBox="0 0 58 58"><circle class="b" cx="29" cy="29" r="25"/><circle class="f" id="pRing" cx="29" cy="29" r="25"/></svg><span id="pIco"></span></button></div>` },
  { n: 'Water Reminder', h: `<div class="water"><div><div class="big"><span id="wV">0.0</span> <small id="wG">/ 1.5 L</small></div><div class="pb"><i id="wB"></i></div><div class="sub" id="wS"></div>
     <div class="btns"><button class="btn p" id="wD">+ Drink 250 ml</button><button class="btn" id="wGo">Goal</button></div></div><div class="hist" id="wH"></div></div>` },
  { n: 'To-do list', h: `<div class="todo"><div class="thead"><b id="tN">0/0</b><span class="sub">Tick tasks off as you go</span></div><div id="tl"></div><input id="ti" placeholder="Add a task and press Enter" maxlength="60"></div>` },
  { n: 'Shelf', h: `<div class="shelf" id="sh"></div>` },
  { n: 'Power', h: `<div class="power">
     <button class="pw" data-a="lock"><svg viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/></svg><span>Lock</span></button>
     <button class="pw" data-a="sleep"><svg viewBox="0 0 24 24"><path d="M20 14.5A8 8 0 019.5 4a8 8 0 1010.5 10.5z"/></svg><span>Sleep</span></button>
     <button class="pw" data-a="restart"><svg viewBox="0 0 24 24"><path d="M20 11a8 8 0 10-2.3 5.7"/><path d="M20 4v7h-7"/></svg><span>Restart</span></button>
     <button class="pw" data-a="shutdown"><svg viewBox="0 0 24 24"><path d="M12 3v9"/><path d="M6.3 6.8a8 8 0 1011.4 0"/></svg><span>Shut down</span></button></div>` }
];

const EXTRA = [
  { n: 'Weather', h: `<div class="wp"><div class="wi" id="wpIco"></div><div class="wm"><div class="wt" id="wpT">--°</div><div class="sub" id="wpD">Memuat cuaca…</div><div class="sub" id="wpC"></div></div><div class="wst" id="wpS"></div></div>` },
  { n: 'Calendar', h: `<div class="cal"><div class="cd"><b id="cDay">--</b><span id="cDate"></span></div><div class="cw" id="cWeek"></div></div>` },
  { n: 'Stopwatch', h: `<div class="sw2"><div class="stt" id="swT">00:00.00</div><div class="swb"><button class="chipb on" id="swGo">Start</button><button class="chipb" id="swLap">Lap</button><button class="chipb" id="swRs">Reset</button></div><div class="laps" id="swL"></div></div>` },
  { n: 'Clipboard', h: `<div class="clp"><div id="clL"></div></div>` },
  { n: 'Timer', h: `<div class="tm"><div class="tmr"><svg viewBox="0 0 80 80"><circle class="b" cx="40" cy="40" r="35"/><circle class="f" id="tmRing" cx="40" cy="40" r="35"/></svg><div id="tmT">05:00</div></div><div class="tmc"><div class="tmp"><button data-t="1">1m</button><button data-t="5" class="on">5m</button><button data-t="10">10m</button><button data-t="15">15m</button><button data-t="30">30m</button></div><div class="swb"><button class="chipb on" id="tmGo">Start</button><button class="chipb" id="tmAdd">+1m</button><button class="chipb" id="tmRs">Reset</button></div></div></div>` },
  { n: 'Notes', h: `<div class="nt"><textarea id="ntA" placeholder="Catatan cepat… (tersimpan otomatis)" maxlength="800"></textarea></div>` },
  { n: 'World Clock', h: `<div class="wc" id="wcG"></div>` },
  { n: 'System', h: `<div class="sy"><div class="sr"><label>CPU</label><div class="b2"><i id="syC"></i></div><b id="syCv">--</b></div><div class="sr"><label>RAM</label><div class="b2"><i id="syM"></i></div><b id="syMv">--</b></div><div class="sr"><label>Disk C:</label><div class="b2"><i id="syD"></i></div><b id="syDv">--</b></div><div class="sub" id="syU"></div></div>` },
  { id: 'games', n: 'Game', h: `<div class="gm"><div class="gmh"><span id="gmN">Memuat…</span><button id="gmR" title="Muat ulang">↻</button></div><div class="gl" id="gl"></div></div>` },
  { n: 'Launcher', h: `<div class="lc">${[['calc', '🧮', 'Kalkulator'], ['notepad', '📝', 'Notepad'], ['explorer', '📁', 'File'], ['taskmgr', '📊', 'Task Mgr'], ['settings', '⚙️', 'Setelan'], ['snip', '✂️', 'Screenshot'], ['cmd', '💻', 'Terminal'], ['web', '🌐', 'Browser']].map(x => `<button data-l="${x[0]}"><span>${x[1]}</span><small>${x[2]}</small></button>`).join('')}</div>` }
];
const ORDER = ['Music', 'Lyrics', 'Weather', 'Pomodoro', 'Timer', 'Water Reminder', 'To-do list', 'Notes', 'Calendar', 'World Clock', 'Stopwatch', 'System', 'Clipboard', 'Launcher', 'Game', 'Shelf', 'Power'];
PAGES.push(...EXTRA); PAGES.sort((a, b) => ORDER.indexOf(a.n) - ORDER.indexOf(b.n));
const MUSIC = PAGES.find(p => p.n === 'Music');
const pg = n => PAGES.findIndex(p => p.n === n);
const pagesEl = $('#pages'), dotsEl = $('#dots');
PAGES.forEach((p, i) => {
  const d = document.createElement('div'); d.className = 'page'; d.innerHTML = p.h; pagesEl.appendChild(d); p.el = d;
  const dot = document.createElement('i'); dot.onclick = () => go(i); dotsEl.appendChild(dot);
});
let cur = store.get('page', 0);
function go(i) {
  cur = Math.max(0, Math.min(PAGES.length - 1, i)); store.set('page', cur);
  PAGES.forEach((p, k) => { p.el.style.setProperty('--o', k - cur); p.el.classList.toggle('on', k === cur); dotsEl.children[k].classList.toggle('on', k === cur) });
  $('#pTitle').textContent = PAGES[cur].n; $('#pNum').textContent = (cur + 1) + ' / ' + PAGES.length;
  if (PAGES[cur].id === 'games') setTimeout(loadGames, 0);
}
go(cur);
let wheelT = 0;
document.addEventListener('wheel', e => {
  if (e.target.closest('#tl,#ntA,#gl')) return;
  const n = performance.now(); if (n - wheelT < 320) return;
  const d = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
  if (Math.abs(d) > 4) { wheelT = n; go(cur + (d > 0 ? 1 : -1)); }
}, { passive: true });
let sx = null;
pagesEl.addEventListener('pointerdown', e => { if (!e.target.closest('button,input,.fi,#tl')) sx = e.clientX; });
window.addEventListener('pointerup', e => { if (sx !== null) { const d = e.clientX - sx; if (Math.abs(d) > 50) go(cur + (d < 0 ? 1 : -1)); sx = null; } });
$('#pPrev').onclick = () => go((cur + PAGES.length - 1) % PAGES.length); $('#pNext').onclick = () => go((cur + 1) % PAGES.length);
document.addEventListener('keydown', e => { if (['INPUT', 'TEXTAREA'].includes(e.target.tagName)) return; if (e.key === 'ArrowRight') go(cur + 1); if (e.key === 'ArrowLeft') go(cur - 1); });

/* ---------- state from main ---------- */
let open = false;
api.onState(v => { open = v; notch.classList.toggle('open', v); refreshChr(); if (!v) { document.activeElement?.blur(); api.pin(false); document.getElementById('pmenu').classList.remove('show'); setTimeout(() => charAnim('a-jump', 750), 500); } });
api.onCursor((x, y) => { faceEl.style.setProperty('--ex', x); faceEl.style.setProperty('--ey', y); });
api.onAttention(() => { notch.classList.add('pulse'); setTimeout(() => notch.classList.remove('pulse'), 1900); });

/* clock */
const clk = () => { $('#clock').textContent = new Date().toLocaleString('id-ID', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', hour12: false }).replace(',', '').replace('.', ':'); };
clk(); setInterval(clk, 5000);

/* ---------- settings / karakter / ambient ---------- */
const root = document.documentElement, faceEl = $('#face'), fxEl = $('#fx'), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const merge = (a, b) => { const o = { ...a }; for (const k in b) o[k] = (b[k] && typeof b[k] === 'object' && !Array.isArray(b[k])) ? merge(a[k] || {}, b[k]) : b[k]; return o; };
let S = { ambientFx: true, shape: 'notch', tint: 'black', character: 'kitty', showClock: true, showWeather: true, showBattery: true, ambient: true, ambientLevel: 65, randomAnim: true, randomFreq: 'normal', clock24: true, unit: 'c', anim: { music: true, volume: true, download: true, copy: true, battery: true } };
let artC = null, tmpAmb = '', ambT = 0, chr = null, baseTheme = ['#ff9a62', '#ff6fae'], toast = null, toastT = 0, tmpMood = '', dl = null, wx = null;
let lastArt = null, M, L = [], lastIdx = -2, lastLive = null, beatOn = false, szKey = '', ft = 0, lp = false, curWords = [], curLn = null, actWords = [], nextNote = 0;
const B = { ok: false, level: 1, charging: false, low: false, lowFired: false, critFired: false };
const esc = s => String(s ?? '').replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
const ambEl = $('#amb'), theme = () => (artC && M && M.playing) ? [artC, baseTheme[1]] : baseTheme;
function setTheme(a, b) { root.style.setProperty('--a1', a); root.style.setProperty('--a2', b || a); }
function applyChar() {
  const c = CHARS[S.character] || CHARS.kitty; faceEl.innerHTML = c.svg(); chr = faceEl.firstElementChild; baseTheme = [c.c1, c.c2];
  if (!toast) setTheme(...theme()); refreshChr(); charAnim('a-jump', 750); burst(['♥', '✦'], 4, c.c1);
}
function refreshChr() {
  if (!chr) return;
  const mood = toast ? toast.mood : (tmpMood || (M && M.playing && S.anim.music ? 'happy' : (B.low ? 'sad' : '')));
  [...chr.classList].forEach(c => c.startsWith('m-') && chr.classList.remove(c));
  if (mood) chr.classList.add('m-' + mood);
  chr.classList.toggle('a-dance', !!(M && M.playing && !open && !toast && S.anim.music));
}
function charAnim(cls, ms) { if (!chr) return; chr.classList.remove(cls); void chr.getBoundingClientRect(); chr.classList.add(cls); setTimeout(() => chr && chr.classList.remove(cls), ms); }
function setTmpMood(m, ms) { tmpMood = m; refreshChr(); setTimeout(() => { if (tmpMood === m) { tmpMood = ''; refreshChr(); } }, ms); }
function originOf(el) { const r = el.getBoundingClientRect(), c = $('#clip').getBoundingClientRect(); return { x: r.left - c.left + r.width / 2, y: r.top - c.top + r.height / 2 }; }
function spawn(txt, cls, x, y, v) { const e = document.createElement('i'); e.className = 'p ' + cls; e.textContent = txt; e.style.left = x + 'px'; e.style.top = y + 'px'; for (const k in v) e.style.setProperty(k, v[k]); fxEl.appendChild(e); setTimeout(() => e.remove(), 2000); }
function burst(list, n, color, from) {
  if (!chr) return; const o = originOf(from || faceEl);
  for (let i = 0; i < n; i++) setTimeout(() => spawn(list[i % list.length], 'fl', o.x + 6 + Math.random() * 12, o.y, { '--dx': (8 + Math.random() * 34) + 'px', '--dy': -(4 + Math.random() * 12) + 'px', '--c': color || '#fff', '--s': (10 + Math.random() * 5) + 'px', '--r': (Math.random() * 40 - 20) + 'deg' }), i * 110);
}
function confetti(from) {
  const cols = ['#34d399', '#fbbf24', '#60a5fa', '#f472b6', '#a78bfa', '#f87171'], o = originOf(from || $('#act .ico') || faceEl);
  for (let i = 0; i < 28; i++) { const a = Math.random() * Math.PI * 2, d = 30 + Math.random() * 90; spawn('', 'conf', o.x, o.y, { '--x': Math.cos(a) * d * 1.6 + 'px', '--y': (Math.sin(a) * d * .55 + 10) + 'px', '--r': (Math.random() * 720 - 360) + 'deg', '--c': cols[i % 6], '--dl': Math.random() * .12 + 's' }); }
}

/* aksi acak karakter */
let rt = 0;
const RAND = [
  { n: 'a-jump', ms: 750 }, { n: 'a-wiggle', ms: 900 }, { n: 'a-spin', ms: 850 }, { n: 'a-squish', ms: 800 }, { n: 'a-look', ms: 2200 }, { n: 'a-ears', ms: 1100 },
  { n: 'a-jump', ms: 750, mood: 'happy', mm: 1000, fx: ['✦', '★'], col: '#fde047' },
  { n: 'a-squish', ms: 800, mood: 'love', mm: 2400, fx: ['♥'], col: '#fb7185' },
  { mood: 'sleepy', mm: 3400, fx: ['z', 'Z', 'z'], col: '#93c5fd' },
  { n: 'a-jump', ms: 750, mood: 'surprise', mm: 1100, fx: ['!'], col: '#fbbf24' }
];
function ambPulse(fx, ms) { tmpAmb = fx; ambEl.dataset.fx = ''; void ambEl.offsetWidth; applyMode(); clearTimeout(ambT); ambT = setTimeout(() => { tmpAmb = ''; applyMode(); }, ms); }
function doRand(force) {
  if (!force && (!S.randomAnim || open || toast || (M && M.playing))) return;
  const a = RAND[Math.floor(Math.random() * RAND.length)];
  if (a.n) charAnim(a.n, a.ms); if (a.mood) setTmpMood(a.mood, a.mm);
  ambPulse(a.mood === 'love' ? 'love' : a.mood === 'sleepy' ? 'sleep' : a.mood === 'surprise' ? 'jump' : a.mood === 'happy' ? 'jump' : 'jump', a.mm || a.ms || 900); if (a.fx) burst(a.fx, a.fx.length > 1 ? 4 : 3, a.col);
}
function scheduleRand() {
  clearTimeout(rt); const r = { rare: [9000, 16000], normal: [4000, 8500], often: [2000, 4500] }[S.randomFreq] || [4000, 8500];
  rt = setTimeout(() => { doRand(); scheduleRand(); }, r[0] + Math.random() * (r[1] - r[0]));
}

/* ---------- info idle: jam / cuaca / baterai ---------- */
function tickClock() {
  const n = new Date(); let h = n.getHours(); if (!S.clock24) h = h % 12 || 12;
  const s = String(h).padStart(2, '0') + String(n.getMinutes()).padStart(2, '0'), ds = $$('#iClock .d');
  [...s].forEach((c, i) => { if (ds[i].textContent !== c) { ds[i].textContent = c; ds[i].classList.remove('roll'); void ds[i].offsetWidth; ds[i].classList.add('roll'); } });
}
setInterval(tickClock, 1000);
const WX = {
  sun: '<g class="rays" stroke="#fcd34d" stroke-width="1.7" stroke-linecap="round"><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M18.7 5.3l-1.6 1.6M6.9 17.1l-1.6 1.6"/></g><circle cx="12" cy="12" r="4.3" fill="#fbbf24"/>',
  moon: '<path d="M19 14.5A7.5 7.5 0 019.5 5a7.5 7.5 0 109.5 9.5z" fill="#e5e7eb"/><circle class="tw" cx="18" cy="5" r="1" fill="#fde68a"/><circle class="tw" cx="21" cy="9" r=".7" fill="#fde68a" style="animation-delay:.8s"/>',
  cloud: '<path class="cl" d="M7 18h10a4 4 0 000-8 5.5 5.5 0 00-10.6 1.5A3.3 3.3 0 007 18z" fill="#cbd5e1"/>',
  rain: '<path class="dr" d="M8 18.5l-1 3" stroke="#60a5fa" stroke-width="1.7" stroke-linecap="round"/><path class="dr" d="M12 18.5l-1 3" stroke="#60a5fa" stroke-width="1.7" stroke-linecap="round"/><path class="dr" d="M16 18.5l-1 3" stroke="#60a5fa" stroke-width="1.7" stroke-linecap="round"/>',
  snow: '<circle class="dr" cx="8" cy="20" r="1.1" fill="#e0f2fe"/><circle class="dr" cx="12" cy="20" r="1.1" fill="#e0f2fe"/><circle class="dr" cx="16" cy="20" r="1.1" fill="#e0f2fe"/>',
  zap: '<path class="zap" d="M12.5 12l-3 5h2.6l-1 4.5 4.2-6h-2.7l1.4-3.5z" fill="#fde047"/>',
  fog: '<path class="fg" d="M5 20h14M7 22.5h10" stroke="#94a3b8" stroke-width="1.5" stroke-linecap="round"/>'
};
function wxIcon(code, day) {
  let g; const c = WX.cloud.replace('d="M7 18', 'd="M7 15').replace('fill="#cbd5e1"', 'fill="#cbd5e1" transform="translate(0 -3)"');
  const cl = '<g transform="translate(0 -3)">' + WX.cloud + '</g>';
  if (code === 0) g = day ? WX.sun : WX.moon;
  else if (code <= 2) g = (day ? '<g transform="translate(4 -4) scale(.7)">' + WX.sun + '</g>' : '<g transform="translate(3 -3) scale(.75)">' + WX.moon + '</g>') + cl;
  else if (code === 3) g = cl;
  else if (code === 45 || code === 48) g = cl + WX.fog;
  else if (code >= 71 && code <= 77 || code === 85 || code === 86) g = cl + WX.snow;
  else if (code >= 95) g = cl + WX.zap;
  else g = cl + WX.rain;
  return '<svg class="wx" viewBox="0 0 24 24">' + g + '</svg>';
}
function renderWx() {
  const e = $('#iWx'); if (!wx || !S.showWeather) { e.style.display = 'none'; return; }
  e.style.display = ''; e.innerHTML = wxIcon(wx.code, wx.day) + '<span>' + wx.temp + '°</span>';
}
function batSvg(lv, chg) {
  const col = chg ? '#34d399' : lv <= .15 ? '#fb7185' : lv <= .3 ? '#fbbf24' : '#34d399', w = Math.max(1.2, 17.8 * Math.min(1, lv));
  return `<svg class="bat" viewBox="0 0 26 12" style="--bc:${col}"><rect class="shell" x=".6" y=".6" width="21.4" height="10.8" rx="3.2"/><rect class="tip" x="23" y="3.6" width="2" height="4.8" rx="1"/><rect class="lvl" x="2.4" y="2.4" width="${w}" height="7.2" rx="1.8"/>${chg ? '<path class="bolt" d="M12.6 2.2l-3.8 4.4h2.6l-.8 3.2 3.8-4.4h-2.6z"/>' : ''}</svg>`;
}
function renderBat() {
  const e = $('#iBat'); if (!B.ok || !S.showBattery) { e.style.display = 'none'; return; }
  e.style.display = ''; e.className = (B.charging ? 'chg ' : '') + (B.low ? 'low' : '');
  e.innerHTML = batSvg(B.level, B.charging) + '<span>' + Math.round(B.level * 100) + '%</span>';
}
function idleWidth() {
  let w = 0, n = 0; if (S.showClock) { w += 58; n++; } if (S.showWeather && wx) { w += 64; n++; } if (S.showBattery && B.ok) { w += 66; n++; }
  return n ? 62 + 16 + w + (n - 1) * 12 : 132;
}
if (navigator.getBattery) navigator.getBattery().then(b => {
  B.ok = true; B.level = b.level; B.charging = b.charging; B.low = !b.charging && b.level <= .15; renderBat(); applyMode();
  b.addEventListener('chargingchange', () => {
    B.charging = b.charging; B.level = b.level; B.low = !b.charging && b.level <= .15; renderBat(); refreshChr();
    if (b.charging) { B.lowFired = false; B.critFired = false; if (S.anim.battery) showToast(tPlug(b.level)); }
    else if (S.anim.battery) showToast(tUnplug(b.level));
    applyMode();
  });
  b.addEventListener('levelchange', () => {
    B.level = b.level; B.low = !b.charging && b.level <= .15; renderBat(); refreshChr();
    if (!b.charging && S.anim.battery) {
      if (b.level <= .05 && !B.critFired) { B.critFired = true; showToast(tLow(b.level, true)); }
      else if (b.level <= .15 && !B.lowFired) { B.lowFired = true; showToast(tLow(b.level)); }
    }
    if (b.level > .2) { B.lowFired = false; B.critFired = false; }
  });
  if (B.low && S.anim.battery) setTimeout(() => { B.lowFired = true; showToast(tLow(B.level)); }, 2500);
});

/* ---------- mode & ukuran capsule ---------- */
function popNotch() { notch.classList.remove('pop'); void notch.offsetWidth; notch.classList.add('pop'); }
function flashTitle(t) {
  if (!t) return; const el = $('#pTitle'); el.textContent = t; el.classList.remove('flash'); void el.offsetWidth; el.classList.add('flash');
  clearTimeout(ft); ft = setTimeout(() => { el.textContent = PAGES[cur].n; el.classList.remove('flash'); }, 1600);
}
function applyMode() {
  const mode = toast ? 'toast' : (M && M.playing && S.anim.music ? 'music' : 'idle'), iw = idleWidth();
  ['toast', 'music', 'idle'].forEach(m => notch.classList.toggle('m-' + m, m === mode));
  const [w, h] = toast ? [toast.w || 340, toast.h || 44] : mode === 'music' ? [440, 40] : [iw, 38];
  root.style.setProperty('--cw', w + 'px'); root.style.setProperty('--ch', h + 'px'); root.style.setProperty('--fx', (mode === 'idle' && iw === 132) ? '50%' : '34px');
  const fx = !S.ambientFx ? '' : toast ? (toast.amb || toast.type) : (tmpAmb || (mode === 'music' ? 'music' : ''));
  if ((ambEl.dataset.fx || '') !== fx) ambEl.dataset.fx = fx;
  const k = w + 'x' + h; if (k !== szKey) { szKey = k; api.setSize(w, h); }
}
const SHAPES = {
  notch: { ri: '0 0 20px 20px', ro: '0 0 30px 30px', top: 0 },
  pill: { ri: '999px', ro: '44px', top: 8 },
  squircle: { ri: '16px', ro: '26px', top: 8 },
  blob: { ri: '22px 12px 20px 14px / 16px 22px 14px 20px', ro: '34px 22px 32px 24px / 26px 32px 24px 30px', top: 8, alt: ['14px 22px 14px 22px / 22px 14px 22px 14px', '24px 14px 22px 12px / 14px 22px 12px 22px'] },
  glass: { ri: '999px', ro: '44px', top: 8, ring: 'inset 0 0 0 1.5px rgba(255,255,255,.3)' }
};
let morphT = 0, morphI = 0;
function applyShape() {
  const sh = SHAPES[S.shape] || SHAPES.notch; let ring = sh.ring || 'none', bg = '#000';
  root.style.setProperty('--ri', sh.ri); root.style.setProperty('--ro', sh.ro); root.style.setProperty('--top', sh.top + 'px');
  if (S.tint === 'tinted') bg = 'linear-gradient(135deg,color-mix(in srgb,var(--a1) 28%,#050507),color-mix(in srgb,var(--a2) 28%,#050507))';
  if (S.tint === 'ring') ring = 'inset 0 0 0 1.6px color-mix(in srgb,var(--a1) 85%,transparent)';
  root.style.setProperty('--bg', bg); root.style.setProperty('--ring', ring);
  notch.dataset.shape = S.shape; notch.dataset.tint = S.tint; notch.dataset.flare = (S.shape === 'notch' && S.tint === 'black') ? '1' : '0';
  clearInterval(morphT); if (sh.alt) { const all = [sh.ri, ...sh.alt]; morphT = setInterval(() => root.style.setProperty('--ri', all[++morphI % all.length]), 3200); }
}
function applySettings(s) {
  const pc = S.character; S = merge(S, s); applyShape(); if (!chr || pc !== S.character) applyChar(); root.style.setProperty('--ao', S.ambient ? S.ambientLevel / 100 : 0);
  $('#iClock').style.display = S.showClock ? '' : 'none'; tickClock(); renderWx(); renderBat(); applyMode(); scheduleRand();
}

/* ---------- toast engine ---------- */
function showToast(o) {
  const a = $('#act'), same = toast && toast.type === o.type && o.upd, prev = toast; toast = o;
  if (same) o.upd(a, prev);
  else { a.innerHTML = o.html; o.after && o.after(a); setTheme(...(o.c || theme())); ambEl.dataset.fx = ''; void ambEl.offsetWidth; popNotch(); }
  clearTimeout(toastT); if (!o.sticky) toastT = setTimeout(endToast, o.ms || 2400);
  applyMode(); refreshChr();
  if (!same) { if (o.jump) charAnim('a-jump', 750); if (o.fx) setTimeout(o.fx, 150); }
  if (open && o.title) flashTitle(o.title);
}
function endToast() {
  toast = null; setTheme(...theme());
  if (dl && S.anim.download) showDl(); else { applyMode(); refreshChr(); }
}
const IC = {
  spk: '<svg viewBox="0 0 24 24"><path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path class="w1" d="M15.5 9a4 4 0 010 6"/><path class="w2" d="M18 6.5a8 8 0 010 11"/></svg>',
  mute: '<svg viewBox="0 0 24 24"><path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path class="xx" d="M16 9.5l5 5M21 9.5l-5 5"/></svg>'
};
const OK = '<div class="ico"><svg viewBox="0 0 24 24"><circle class="ring" cx="12" cy="12" r="10"/><path class="chk" d="M7 12.5l3.2 3.2L17 9"/></svg></div>';
const fmtB = b => b > 1073741824 ? (b / 1073741824).toFixed(2) + ' GB' : b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB';

function tPlay(title, artist) {
  return { type: 'play', mood: 'happy', c: ['#22d3ee', '#a78bfa'], w: 370, ms: 2800, jump: true, title: 'Now playing', fx: () => burst(['♪', '♫', '♬'], 7, '#67e8f9'),
    after(a) { if (M.art) { const e = $('.art2', a); if (e) e.style.backgroundImage = `url("${M.art}")`; } },
    html: `<div class="tk">${M && M.art ? '<div class="art2"></div>' : '<div class="vinyl"></div>'}<div class="txt"><b>${esc(title)}</b><small>${esc(artist || 'Now playing')}</small></div><div class="mbars"><i></i><i></i><i></i><i></i></div></div>` };
}
const VSEG = 14;
function tVol(v, mute, dir) {
  return { type: 'volume', v, mute, dir, w: 330, ms: 1600, c: ['#60a5fa', '#a78bfa'], mood: mute ? 'sleepy' : dir > 0 ? 'happy' : (v <= 25 ? 'sleepy' : ''), title: mute ? 'Muted' : 'Volume ' + v + '%',
    html: `<div class="tk vol"><div class="ico"></div><div class="vsegs">${Array.from({ length: VSEG }, (_, i) => `<i style="--h:${32 + i * 5}%"></i>`).join('')}</div><div class="vn"><span class="vdir"></span><b></b></div></div>`,
    after(a) { this.upd(a, null); }, upd(a, prev) {
      const ico = $('.ico', a), lvl = mute ? 0 : Math.ceil(v / 100 * VSEG), was = prev ? prev.mute : null;
      if (was !== mute || !ico.innerHTML) ico.innerHTML = mute || v === 0 ? IC.mute : IC.spk;
      const w1 = $('.w1', ico), w2 = $('.w2', ico); if (w1) { w1.style.opacity = v > 0 ? 1 : .2; w2.style.opacity = v > 50 ? 1 : .15; }
      ico.classList.remove('up', 'dn'); void ico.offsetWidth; if (dir) ico.classList.add(dir > 0 ? 'up' : 'dn');
      $$('.vsegs i', a).forEach((e, i) => { e.classList.toggle('on', i < lvl); e.classList.toggle('pk', i === lvl - 1 && !!dir); });
      const n = $('.vn b', a); n.textContent = mute ? 'Mute' : v; n.classList.remove('bump'); void n.offsetWidth; n.classList.add('bump');
      const d = $('.vdir', a); d.className = 'vdir ' + (dir > 0 ? 'up' : 'dn'); d.textContent = dir > 0 ? '▲' : dir < 0 ? '▼' : ''; void d.offsetWidth; if (dir) d.classList.add('go');
      root.style.setProperty('--vv', mute ? 0 : v / 100); ambEl.classList.remove('rp', 'rn'); void ambEl.offsetWidth; if (dir) ambEl.classList.add(dir > 0 ? 'rp' : 'rn');
      setTheme(...(v > 80 ? ['#f472b6', '#fb923c'] : v < 20 ? ['#38bdf8', '#818cf8'] : ['#60a5fa', '#a78bfa']));
    } };
}
function dlTexts(a) {
  if (!dl) return; const nm = /^unconfirmed/i.test(dl.name || '') || !dl.name ? 'File' : dl.name;
  $('.txt b', a).textContent = 'Downloading…'; $('.txt small', a).textContent = nm + (dl.size ? ' · ' + fmtB(dl.size) : '');
  $('.spd', a).textContent = dl.speed > 1024 ? fmtB(dl.speed) + '/s' : '';
}
function tDl() {
  return { type: 'dl', mood: 'happy', sticky: true, w: 370, c: ['#38bdf8', '#34d399'], title: 'Downloading…',
    html: `<div class="tk"><div class="dlico"><svg viewBox="0 0 24 24"><path class="ar" d="M12 3v11M7.5 10l4.5 4.5 4.5-4.5"/><path class="tr" d="M4 20h16"/></svg></div><div class="txt"><b></b><small></small><div class="pbar"><i></i></div></div><div class="spd"></div></div>`,
    after(a) { dlTexts(a); }, upd(a) { dlTexts(a); } };
}
function showDl() { if (!dl) return; dl.t = Date.now(); showToast(tDl()); }
function tDone(name) {
  return { type: 'done', mood: 'happy', w: 370, h: 66, ms: 3400, c: ['#34d399', '#fbbf24'], jump: true, title: 'Download complete', fx: () => { confetti(); burst(['✦', '★'], 5, '#fde047'); },
    html: `<div class="tk ok">${OK}<div class="txt"><b>Download complete</b><small>${esc(name)}</small></div></div>` };
}
function tCopy(d) {
  const kind = d.kind === 'file' ? 'File copied' : d.kind === 'image' ? 'Image copied' : 'Copied', sub = d.kind === 'file' ? d.name : d.kind === 'image' ? d.w + ' × ' + d.h : (d.p || d.n + ' characters');
  return { type: 'copy', mood: 'happy', w: 340, ms: 2100, c: ['#60a5fa', '#a78bfa'], jump: true, title: kind, fx: () => burst(['✦'], 3, '#93c5fd'),
    html: `<div class="tk"><div class="sheets"><i></i><i></i></div><div class="txt"><b>${kind}</b><small>${esc(sub)}</small></div></div>` };
}
function tPaste(d) {
  const sub = d.kind === 'file' ? d.name : d.kind === 'image' ? d.w + ' × ' + d.h : (d.p || '');
  return { type: 'paste', mood: 'surprise', w: 340, ms: 1900, c: ['#fbbf24', '#f472b6'], title: 'Pasted', fx: () => { setTmpMood('happy', 900); burst(['✓'], 2, '#fde68a'); },
    html: `<div class="tk"><div class="pst"><i></i><span class="pl"></span></div><div class="txt"><b>Pasted</b><small>${esc(sub || 'from clipboard')}</small></div></div>` };
}
function tPlug(lv) {
  const p = Math.round(lv * 100);
  return { type: 'plug', mood: 'love', w: 350, h: 54, ms: 3000, c: ['#34d399', '#fde047'], jump: true, title: 'Charging', fx: () => burst(['⚡', '♥', '✦'], 6, '#fde047'),
    html: `<div class="tk"><div class="batbig">${batSvg(lv, true)}<u></u><u></u><u></u></div><div class="txt"><b>Charging</b><small>Charger connected</small></div><div class="pct"><b>${p}</b><small>%</small></div></div>` };
}
function tUnplug(lv) {
  const p = Math.round(lv * 100);
  return { type: 'unplug', mood: 'surprise', w: 350, h: 54, ms: 2800, c: ['#fbbf24', '#fb923c'], title: 'Unplugged', fx: () => setTimeout(() => setTmpMood('sleepy', 1200), 700),
    html: `<div class="tk"><div class="unp"><svg viewBox="0 0 48 24"><rect x="2" y="5" width="11" height="14" rx="3"/><path d="M6 10v1.5M9.6 10v1.5"/><g class="plg"><rect x="19" y="6" width="10" height="12" rx="2.5"/><path d="M19 9.5h-8M19 14.5h-8"/><path d="M29 12h5c4 0 4 6 10 6"/></g><g class="sp" stroke="#fde047"><path d="M15 3l1 3M18 5l-1 3M13 20l2-2"/></g></svg></div><div class="txt"><b>Unplugged</b><small>Running on battery</small></div><div class="pct"><b>${p}</b><small>%</small></div></div>` };
}
function tLow(lv, crit) {
  const p = Math.round(lv * 100);
  return { type: 'low', mood: 'scared', w: 360, h: 56, ms: 5200, c: ['#fb7185', '#f43f5e'], title: crit ? 'Battery critical' : 'Battery low',
    fx: () => { burst(['💧'], 3, '#7dd3fc'); setTimeout(() => setTmpMood('sad', 2000), 100); },
    html: `<div class="tk"><div class="lowb">${batSvg(lv, false)}</div><div class="txt"><b>${crit ? 'Battery critical' : 'Battery low'}</b><small>${p}% left · plug in the charger</small></div><div class="pct"><b>${p}</b><small>%</small></div></div>` };
}
setInterval(() => { if (dl && Date.now() - dl.t > 10000) { dl = null; if (toast && toast.type === 'dl') endToast(); } }, 3000);
const onDlProg = d => { if (!dl) dl = {}; Object.assign(dl, d, { t: Date.now() }); if (toast && toast.type === 'dl') showToast(tDl()); else if (!toast) showDl(); };
const onDlDone = d => { dl = null; showToast(tDone(d.name)); };

/* ---------- music ---------- */
const fmt = s => { s = Math.max(0, Math.floor(s)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0') };
const DEMO_LYR = ['Neon rain on empty streets', 'We follow the lights downtown', 'Every window hums a song', 'Only we can hear the sound', 'Hold the night a little longer', 'Let the city carry us', 'Stars are paper, we are fire', 'Burning slow and burning true', 'Take my hand and do not stop', 'Morning is a world away', 'Neon rain on empty streets', 'Keep the glow and never fade'].map((t, i) => ({ t: i * 14, text: t }));
function setDemo() { M = { demo: true, key: 'demo', title: 'Neon Rain', artist: 'Rav Studio', dur: 180, pos: 0, rp: 0, playing: false, t0: performance.now() }; setLyr(DEMO_LYR); }
const pos = () => { let p = M.pos + (M.playing ? (performance.now() - M.t0) / 1000 : 0); if (M.dur) p = Math.min(p, M.dur); return Math.max(0, p); };
function setLyr(a) {
  L = a || []; lastIdx = -2; lastLive = null; actWords = []; const el = $('#lines'); el.innerHTML = '';
  (L.length ? L : [{ text: 'No synced lyrics found' }]).forEach(l => { const d = document.createElement('div'); d._t = l.text || '♪'; d.textContent = d._t; el.appendChild(d); }); el.style.transform = 'translateY(23px)';
}
function parseLrc(s) { const o = []; s.split('\n').forEach(l => { const m = l.match(/^\[(\d+):(\d+(?:\.\d+)?)\](.*)/); if (m) o.push({ t: +m[1] * 60 + +m[2], text: m[3].trim() }); }); return o; }
setDemo();
api.onMedia(m => {
  if (!m) { if (!M.demo) setDemo(); return; }
  const key = m.title + '|' + m.artist, changed = key !== M.key;
  if (!changed && m.playing && !M.playing && S.anim.music) showToast(tPlay(m.title, m.artist));
  const moved = Math.abs((m.pos || 0) - (M.rp || 0)) > 0.01;
  if (changed || moved || m.playing !== M.playing) { M.pos = m.pos || 0; M.t0 = performance.now(); }
  M.rp = m.pos || 0; M.playing = m.playing; M.dur = m.dur || 0; if (m.art) M.art = m.art;
  if (changed) {
    M.demo = false; M.key = key; M.art = m.art || ''; if (m.playing && S.anim.music) showToast(tPlay(m.title, m.artist)); M.title = m.title; M.artist = m.artist || ''; setLyr(null);
    api.getLyrics({ artist: m.artist, title: m.title, dur: m.dur }).then(r => { if (M.key === key && r) setLyr(parseLrc(r)); });
  }
});
$$('.ctl button').forEach(b => b.onclick = () => {
  const k = b.dataset.k;
  if (M.demo) { if (k === 'play') { M.pos = pos(); M.playing = !M.playing; M.t0 = performance.now(); } else { M.pos = 0; M.t0 = performance.now(); } }
  else { if (k === 'play') { M.pos = pos(); M.playing = !M.playing; M.t0 = performance.now(); } api.mediaKey(k); }
});
function wordify(box, text, cls) {
  box.textContent = ''; return text.split(/\s+/).filter(Boolean).map((w, i) => { const s = document.createElement('span'); s.className = cls; s.textContent = w; s.style.setProperty('--i', i); box.appendChild(s); return s; });
}
function liveText(t) {
  if (t === lastLive) return; lastLive = t; const box = $('#lyr');
  $$('.ln:not(.out)', box).forEach(s => { s.classList.add('out'); setTimeout(() => s.remove(), 420); });
  const s = document.createElement('div'); s.className = 'ln'; curWords = wordify(s, t, 'w'); box.appendChild(s); curLn = s;
}
function light(ws, prog) { const n = ws.length; ws.forEach((w, i) => { const on = (i + .4) / n <= prog * 1.08; if (w._on !== on) { w._on = on; w.classList.toggle('lit', on); } }); }
function setActiveLine(idx) {
  const el = $('#lines'); el.style.transform = `translateY(${-(Math.max(idx, 0) - 1) * 23}px)`; actWords = [];
  [...el.children].forEach((c, i) => {
    c.style.setProperty('--d', idx < 0 ? 3 : Math.abs(i - idx)); c.classList.toggle('a', i === idx);
    if (i === idx && L.length && c._t) actWords = wordify(c, c._t, 'w2'); else if (c._w) { c.textContent = c._t; }
    c._w = i === idx && L.length;
  });
}
function artColor(src) {
  if (!src) { artC = null; if (!toast) setTheme(...theme()); return; }
  const im = new Image(); im.onload = () => {
    try {
      const c = document.createElement('canvas'); c.width = c.height = 8; const x = c.getContext('2d'); x.drawImage(im, 0, 0, 8, 8); const d = x.getImageData(0, 0, 8, 8).data; let best = null, bs = -1;
      for (let i = 0; i < d.length; i += 4) { const r = d[i], g = d[i + 1], b = d[i + 2], mx = Math.max(r, g, b), mn = Math.min(r, g, b), sc = (mx - mn) * (mx / 255 + .3); if (sc > bs && mx > 70) { bs = sc; best = [r, g, b]; } }
      if (best) { const k = 210 / Math.max(...best, 1), f = Math.min(1.6, Math.max(1, k)); artC = `rgb(${best.map(v => Math.min(255, Math.round(v * f))).join(',')})`; if (!toast) setTheme(...theme()); }
    } catch { }
  }; im.src = src;
}
function applyArt() {
  artColor(M.art);
  const u = M.art ? `url("${M.art}")` : '';
  $('#art').style.backgroundImage = u; $$('.art').forEach(e => { e.style.backgroundImage = u; e.classList.toggle('has', !!u); }); $$('.art2').forEach(e => e.style.backgroundImage = u);
}
function frame() {
  const now = performance.now() / 1000, p = pos();
  if (M.art !== lastArt) { lastArt = M.art; applyArt(); }
  if (M.playing !== lp) { lp = M.playing; applyMode(); refreshChr(); if (!toast) setTheme(...theme()); syncMusicSlot(); }
  if (open) {
    const f = M.dur ? p / M.dur : 0;
    $$('.mT').forEach(e => e.textContent !== M.title && (e.textContent = M.title));
    $$('.mA').forEach(e => e.textContent !== M.artist && (e.textContent = M.artist));
    $$('.fill').forEach(e => e.style.transform = `scaleX(${f})`);
    $$('.tC').forEach(e => e.textContent = fmt(p));
    $$('.tL').forEach(e => e.textContent = M.dur ? '-' + fmt(M.dur - p) : '');
    $$('.pp').forEach(e => { const k = M.playing ? 'pause' : 'play'; if (e.dataset.i !== k) { e.dataset.i = k; e.innerHTML = I[k]; } });
  }
  if (L.length) {
    let idx = -1; for (let i = 0; i < L.length; i++) if (L[i].t <= p + .25) idx = i; else break;
    if (idx !== lastIdx) { lastIdx = idx; setActiveLine(idx); if (M.playing) liveText(idx >= 0 && L[idx].text ? L[idx].text : '♪ ' + M.title); }
    if (idx >= 0) {
      const nt = L[idx + 1] ? L[idx + 1].t : L[idx].t + 4, prog = Math.max(0, Math.min(1, (p - L[idx].t) / Math.max(.6, (nt - L[idx].t) * .85)));
      if (open) light(actWords, prog);
      if (M.playing && curLn) { light(curWords, prog); const over = curLn.scrollWidth - curLn.clientWidth; curLn.style.transform = over > 0 ? `translateX(${-over * Math.min(1, prog * 1.1)}px)` : ''; }
    }
  } else { if (lastIdx !== -1) { lastIdx = -1; setActiveLine(-1); } if (M.playing) liveText(M.title + (M.artist ? ' · ' + M.artist : '')); }
  if (chr && M.playing && !open && !toast && S.anim.music) {
    const b1 = .5 + .5 * Math.sin(now * 11.9), b2 = .5 + .5 * Math.sin(now * 19.5 + 1.3), b3 = .5 + .5 * Math.sin(now * 7.3 + 2.1);
    const b = Math.min(1, b1 * b1 * .55 + b2 * .3 * b3 + .12);
    chr.style.setProperty('--b', b.toFixed(3)); chr.style.setProperty('--rot', (Math.sin(now * 5.9) * 5).toFixed(2));
    root.style.setProperty('--bt', b.toFixed(3));
    $$('#eq i').forEach((e, i) => { const v = .22 + .78 * (.5 + .5 * Math.sin(now * (9 + i * 3.7) + i * 1.9)) * (.55 + .45 * b); e.style.transform = `scaleY(${v.toFixed(2)})`; });
    if (now > nextNote) { nextNote = now + 1 + Math.random() * 1.3; burst(['♪', '♫', '♬'], 1, baseTheme[Math.random() > .5 ? 0 : 1]); }
    beatOn = true;
  } else if (beatOn) { chr && chr.style.setProperty('--b', 0); chr && chr.style.setProperty('--rot', 0); root.style.setProperty('--bt', 0); beatOn = false; }
  requestAnimationFrame(frame);
}

/* ---------- pomodoro ---------- */
const P = { mode: 'focus', total: 1500, left: 1500, running: false, end: 0 };
const rem = () => P.running ? Math.max(0, (P.end - Date.now()) / 1000) : P.left;
function setMode(m) { P.mode = m; P.total = m === 'focus' ? 1500 : 300; P.left = P.total; P.running = false; renderP(); }
function renderP() {
  const r = rem(), s = Math.ceil(r);
  $('#pTime').textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
  $('#pMode').textContent = P.mode === 'focus' ? 'Focus time' : 'Short break';
  const prog = 1 - r / P.total;
  $('#pRing').style.strokeDashoffset = 157 * (P.running || r < P.total ? prog : 0);
  $('#hr').style.strokeDashoffset = 44 * (1 - (P.running || r < P.total ? prog : 0));
  $('#pBtn').classList.toggle('ring', P.running || r < P.total);
  const k = P.running ? 'pause' : 'play'; if ($('#pIco').dataset.i !== k) { $('#pIco').dataset.i = k; $('#pIco').innerHTML = I[k].replace('<svg', '<svg class="i"'); }
  document.querySelectorAll('[data-m]').forEach(b => b.classList.toggle('on', b.dataset.m === P.mode));
}
$('#pBtn').onclick = () => { flashTitle(P.running ? 'Paused' : (P.mode === 'focus' ? 'Focus started' : 'Break started')); if (P.running) { P.left = rem(); P.running = false; } else { P.end = Date.now() + P.left * 1000; P.running = true; } renderP(); };
document.querySelectorAll('[data-m]').forEach(b => b.onclick = () => setMode(b.dataset.m));
function beep() { try { const a = new AudioContext(); [660, 880, 660].forEach((f, i) => { const o = a.createOscillator(), g = a.createGain(); o.frequency.value = f; o.connect(g); g.connect(a.destination); const t = a.currentTime + i * .22; g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(.25, t + .03); g.gain.exponentialRampToValueAtTime(.0001, t + .2); o.start(t); o.stop(t + .22); }); } catch { } }
setInterval(() => { if (P.running && rem() <= 0) { beep(); api.attention(); setMode(P.mode === 'focus' ? 'short' : 'focus'); go(pg('Pomodoro')); } else if (P.running || open) renderP(); }, 200);
renderP();

/* ---------- water ---------- */
const today = () => new Date().toISOString().slice(0, 10);
let W = store.get('water', { day: today(), ml: 0, goal: 1500, hist: {} });
function renderW() {
  if (W.day !== today()) { W.hist[W.day] = W.ml; W.day = today(); W.ml = 0; }
  $('#wV').textContent = (W.ml / 1000).toFixed(1); $('#wG').textContent = '/ ' + (W.goal / 1000).toFixed(1) + ' L';
  const f = Math.min(1, W.ml / W.goal); $('#wB').style.transform = `scaleX(${f})`;
  $('#wS').textContent = `Today ${Math.round(f * 100)}%` + (f >= 1 ? ' · goal reached 🎉' : ' · stay hydrated');
  const h = $('#wH'); h.innerHTML = '';
  for (let i = 6; i >= 0; i--) { const d = new Date(Date.now() - i * 864e5).toISOString().slice(0, 10); const v = i === 0 ? W.ml : (W.hist[d] || 0); const c = document.createElement('div'); c.innerHTML = `<i style="height:${Math.min(100, v / W.goal * 100)}%"></i>`; h.appendChild(c); }
  store.set('water', W);
}
$('#wD').onclick = () => { W.ml += 250; renderW(); flashTitle('+250 ml 💧'); };
$('#wGo').onclick = () => { W.goal = W.goal >= 3000 ? 1000 : W.goal + 500; renderW(); };
renderW(); setInterval(() => { renderW(); }, 60000);
setInterval(() => { if (W.ml < W.goal && new Date().getHours() >= 8 && new Date().getHours() < 22) { go(pg('Water Reminder')); api.attention(); } }, 3600000);

/* ---------- todo ---------- */
let T = store.get('todo', []);
function renderT() {
  const l = $('#tl'); l.innerHTML = '';
  T.forEach((t, i) => { const d = document.createElement('div'); d.className = 'ti' + (t.d ? ' d' : ''); d.innerHTML = '<i class="ck"></i><span></span><button class="x">✕</button>'; $('span', d).textContent = t.t;
    d.onclick = e => { if (e.target.classList.contains('x')) T.splice(i, 1); else { t.d = !t.d; if (t.d) flashTitle('Task done ✓'); } renderT(); }; l.appendChild(d); });
  $('#tN').textContent = T.filter(t => t.d).length + '/' + T.length; store.set('todo', T);
}
$('#ti').addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.value.trim()) { T.push({ t: e.target.value.trim(), d: false }); e.target.value = ''; renderT(); const l = $('#tl'); l.scrollTop = l.scrollHeight; } });
$('#ti').addEventListener('focus', () => api.pin(true)); $('#ti').addEventListener('blur', () => api.pin(false));
renderT();

/* ---------- shelf ---------- */
let F = store.get('shelf', []);
const sh = $('#sh');
const size = b => b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB';
function renderS() {
  sh.innerHTML = '';
  if (!F.length) sh.innerHTML = '<div class="empty">' + I.tray + 'Drop files here</div>';
  F.forEach((f, i) => { const d = document.createElement('div'); d.className = 'fi'; d.draggable = true;
    d.innerHTML = `<img src="${f.icon}"><b></b><small>${f.size}</small><button class="x">✕</button>`; $('b', d).textContent = f.name;
    d.ondragstart = e => { e.preventDefault(); flashTitle('Dragging…'); api.startDrag(f.path); };
    d.ondblclick = () => api.openPath(f.path);
    $('.x', d).onclick = e => { e.stopPropagation(); F.splice(i, 1); renderS(); };
    sh.appendChild(d); });
  store.set('shelf', F);
}
renderS();
['dragenter', 'dragover'].forEach(n => document.addEventListener(n, e => { e.preventDefault(); if (e.dataTransfer?.types?.includes('Files')) { sh.classList.add('over'); if (cur !== pg('Shelf')) go(pg('Shelf')); if (!window._dg) { window._dg = 1; popNotch(); } } }));
['dragleave'].forEach(n => document.addEventListener(n, e => { if (!e.relatedTarget) { sh.classList.remove('over'); window._dg = 0; } }));
document.addEventListener('drop', async e => {
  e.preventDefault(); sh.classList.remove('over');
  for (const f of e.dataTransfer.files) { const p = api.pathFor(f); if (!p || F.some(x => x.path === p)) continue; F.push({ path: p, name: f.name, size: size(f.size), icon: await api.fileIcon(p) }); }
  renderS(); sh.scrollLeft = sh.scrollWidth; window._dg = 0; popNotch(); flashTitle('Added to Shelf ✓');
});

/* ---------- system events ---------- */
function runTest(n) {
  if (n === 'play') showToast(tPlay('Neon Rain', 'Rav Studio'));
  else if (n === 'volup') [20, 35, 50, 65, 80, 95].forEach((v, i) => setTimeout(() => showToast(tVol(v, false, 1)), i * 220));
  else if (n === 'voldown') [60, 45, 30, 15, 0].forEach((v, i) => setTimeout(() => showToast(tVol(v, v === 0, -1)), i * 220));
  else if (n === 'dl') { let k = 0; const iv = setInterval(() => { k++; onDlProg({ name: 'Rav-Contoh.zip', size: k * 3.1e6, speed: 5.2e6 * (.8 + Math.random() * .4) }); if (k >= 6) { clearInterval(iv); onDlDone({ name: 'Rav-Contoh.zip' }); } }, 600); }
  else if (n === 'dldone') onDlDone({ name: 'Rav-Contoh.zip' });
  else if (n === 'copy') showToast(tCopy({ kind: 'text', n: 24, p: 'Halo dunia, ini teks contoh' }));
  else if (n === 'paste') showToast(tPaste({ kind: 'text', p: 'Halo dunia, ini teks contoh' }));
  else if (n === 'plug') showToast(tPlug(B.ok ? B.level : .62));
  else if (n === 'unplug') showToast(tUnplug(B.ok ? B.level : .62));
  else if (n === 'low') showToast(tLow(.15));
  else if (n === 'crit') showToast(tLow(.05, true));
  else if (n === 'rand') doRand(true);
  else if (n === 'gamebreak') showToast(tBreak(60));
}
api.onEvt((t, d) => {
  if (t === 'test') return runTest(d.name);
  if (t === 'gamebreak') return showToast(tBreak(d.mins));
  if (t === 'volsync') { volPageUpdate(d); vLast = d.v; vLastMute = d.mute; return; }
  if (t === 'volume') volPageUpdate(d); if (t === 'copy') clipAdd(d);
  if (t === 'volume' && S.anim.volume) { const dir = vLast === null ? 0 : (d.mute !== vLastMute ? 0 : Math.sign(d.v - vLast)); vLast = d.v; vLastMute = d.mute; showToast(tVol(d.v, d.mute, dir)); }
  else if (t === 'volume') { vLast = d.v; vLastMute = d.mute; }
  else if (t === 'dlstart' && S.anim.download) { dl = { name: d.name, size: 0, speed: 0, t: Date.now() }; if (!toast || toast.type === 'dl') showDl(); }
  else if (t === 'dlprog' && S.anim.download) onDlProg(d);
  else if (t === 'dlend') { if (dl) { dl = null; if (toast && toast.type === 'dl') endToast(); } }
  else if (t === 'download' && S.anim.download) onDlDone(d);
  else if (t === 'copy' && S.anim.copy) showToast(tCopy(d));
  else if (t === 'paste' && S.anim.copy) showToast(tPaste(d));
});
let vLast = null, vLastMute = false;

/* ---------- power ---------- */
const LABEL = { lock: 'Locking…', sleep: 'Going to sleep…', restart: 'Restarting…', shutdown: 'Shutting down…' };
document.querySelectorAll('.pw').forEach(b => b.onclick = () => {
  const a = b.dataset.a;
  if ((a === 'shutdown' || a === 'restart') && !b.classList.contains('arm')) {
    b.classList.add('arm'); b.querySelector('span').textContent = 'Tap again'; flashTitle('Tap again to confirm');
    setTimeout(() => { b.classList.remove('arm'); b.querySelector('span').textContent = a === 'restart' ? 'Restart' : 'Shut down'; }, 3000); return;
  }
  b.classList.remove('arm'); b.classList.add('go'); flashTitle(LABEL[a]);
  setTimeout(() => { api.power(a); b.classList.remove('go'); b.querySelector('span').textContent = { lock: 'Lock', sleep: 'Sleep', restart: 'Restart', shutdown: 'Shut down' }[a]; }, 650);
});


/* ---------- menu tambahan: Volume, Weather, Calendar, Stopwatch, Clipboard ---------- */
const vSt = { v: 0, mute: false };
function volPageUpdate(d) { vSt.v = d.v; vSt.mute = d.mute; }
api.getVolume().then(v => { if (v) volPageUpdate(v); });

const WXT = c => c === 0 ? 'Cerah' : c <= 2 ? 'Cerah berawan' : c === 3 ? 'Mendung' : (c === 45 || c === 48) ? 'Berkabut' : c >= 95 ? 'Badai petir' : (c >= 71 && c <= 77) || c === 85 || c === 86 ? 'Salju' : c >= 51 ? 'Hujan' : 'Berawan';
function wpRender() {
  if (!wx) return; const u = wx.unit === 'f' ? '°F' : '°C';
  $('#wpIco').innerHTML = wxIcon(wx.code, wx.day); $('#wpT').textContent = wx.temp + u; $('#wpD').textContent = WXT(wx.code); $('#wpC').textContent = wx.city || '';
  $('#wpS').innerHTML = [['Terasa', wx.feel + '°'], ['Lembap', wx.hum + '%'], ['Angin', wx.wind + ' km/j'], ['H/L', (wx.hi ?? '-') + '° / ' + (wx.lo ?? '-') + '°']].map(x => `<div><small>${x[0]}</small><b>${x[1]}</b></div>`).join('');
}
function calRender() {
  const n = new Date(), wk = []; const start = new Date(n); start.setDate(n.getDate() - ((n.getDay() + 6) % 7));
  $('#cDay').textContent = n.getDate(); $('#cDate').textContent = n.toLocaleDateString('id-ID', { weekday: 'long', month: 'long', year: 'numeric' });
  $('#cWeek').innerHTML = Array.from({ length: 7 }, (_, i) => { const d = new Date(start); d.setDate(start.getDate() + i); return `<div class="${d.toDateString() === n.toDateString() ? 'td' : ''}"><small>${d.toLocaleDateString('id-ID', { weekday: 'short' })}</small><b>${d.getDate()}</b></div>`; }).join('');
}
calRender(); setInterval(calRender, 60000);

const SW = { run: false, t0: 0, acc: 0, laps: [] };
const swMs = () => SW.acc + (SW.run ? performance.now() - SW.t0 : 0);
const swFmt = ms => { const c = Math.floor(ms / 10) % 100, s = Math.floor(ms / 1000) % 60, m = Math.floor(ms / 60000); return String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0') + '.' + String(c).padStart(2, '0'); };
function swRender() {
  $('#swT').textContent = swFmt(swMs()); $('#swGo').textContent = SW.run ? 'Pause' : (SW.acc ? 'Lanjut' : 'Start'); $('#swGo').classList.toggle('on', !SW.run);
  $('#swL').innerHTML = SW.laps.slice(-3).reverse().map((l, i) => `<span><small>#${SW.laps.length - i}</small> ${swFmt(l)}</span>`).join('');
}
$('#swGo').onclick = () => { if (SW.run) { SW.acc = swMs(); SW.run = false; } else { SW.t0 = performance.now(); SW.run = true; } swRender(); flashTitle(SW.run ? 'Stopwatch jalan' : 'Dijeda'); };
$('#swLap').onclick = () => { if (SW.run) { SW.laps.push(swMs()); swRender(); } };
$('#swRs').onclick = () => { SW.run = false; SW.acc = 0; SW.laps = []; swRender(); };
setInterval(() => { if (SW.run && open) swRender(); }, 50); swRender();

const CLIP = [];
function clipAdd(d) {
  const label = d.kind === 'file' ? '📄 ' + d.name : d.kind === 'image' ? '🖼 Gambar ' + d.w + '×' + d.h : d.p || '';
  const t = d.kind === 'text' ? d.t : null; if (!label) return;
  const i = CLIP.findIndex(x => x.label === label); if (i >= 0) CLIP.splice(i, 1);
  CLIP.unshift({ label, t }); CLIP.length = Math.min(CLIP.length, 20); clipRender();
}
function clipRender() {
  const l = $('#clL'); l.innerHTML = CLIP.length ? '' : '<div class="empty">Belum ada yang disalin</div>';
  CLIP.slice(0, 4).forEach(c => { const d = document.createElement('div'); d.className = 'ci'; d.innerHTML = '<span></span><i>Salin</i>'; d.firstChild.textContent = c.label; d.onclick = () => { if (c.t) { navigator.clipboard.writeText(c.t).catch(() => { }); flashTitle('Disalin lagi ✓'); } }; l.appendChild(d); });
}
clipRender();
api.onWeather(w => { wx = w; wpRender(); });
api.getWeather().then(w => { if (w) { wx = w; wpRender(); } });


/* ---------- menu tambahan 2: Timer, Notes, World Clock, System, Launcher + daftar menu ---------- */
const TM = { total: 300, left: 300, run: false, end: 0 };
const tmRem = () => TM.run ? Math.max(0, (TM.end - Date.now()) / 1000) : TM.left;
function tmRender() {
  const r = tmRem(), sec = Math.ceil(r); $('#tmT').textContent = String(Math.floor(sec / 60)).padStart(2, '0') + ':' + String(sec % 60).padStart(2, '0');
  $('#tmRing').style.strokeDashoffset = 220 * (1 - (TM.total ? r / TM.total : 0)); $('#tmGo').textContent = TM.run ? 'Pause' : (TM.left < TM.total ? 'Lanjut' : 'Start');
}
function tTimer() {
  return { type: 'alarm', mood: 'surprise', w: 350, h: 54, ms: 6500, c: ['#fbbf24', '#fb923c'], jump: true, title: 'Timer selesai', fx: () => burst(['⏰', '✦'], 5, '#fde047'),
    html: `<div class="tk"><div class="bell">🔔</div><div class="txt"><b>Timer selesai!</b><small>Waktu habis</small></div></div>` };
}
$$('.tmp button').forEach(b => b.onclick = () => { $$('.tmp button').forEach(x => x.classList.toggle('on', x === b)); TM.total = TM.left = +b.dataset.t * 60; TM.run = false; tmRender(); });
$('#tmGo').onclick = () => { if (TM.run) { TM.left = tmRem(); TM.run = false; } else { if (TM.left <= 0) TM.left = TM.total; TM.end = Date.now() + TM.left * 1000; TM.run = true; } flashTitle(TM.run ? 'Timer jalan' : 'Dijeda'); tmRender(); };
$('#tmAdd').onclick = () => { if (TM.run) TM.end += 60000; else { TM.left += 60; TM.total = Math.max(TM.total, TM.left); } tmRender(); };
$('#tmRs').onclick = () => { TM.run = false; TM.left = TM.total; tmRender(); };
setInterval(() => { if (TM.run && tmRem() <= 0) { TM.run = false; TM.left = 0; beep(); api.attention(); showToast(tTimer()); tmRender(); } else if (TM.run && open) tmRender(); }, 250); tmRender();

const nt = $('#ntA'); nt.value = store.get('notes', ''); nt.addEventListener('input', () => store.set('notes', nt.value));
nt.addEventListener('focus', () => api.pin(true)); nt.addEventListener('blur', () => api.pin(false));

const WZ = [['Jakarta', 'Asia/Jakarta'], ['Tokyo', 'Asia/Tokyo'], ['London', 'Europe/London'], ['New York', 'America/New_York']];
function wcRender() {
  const now = new Date(), local = now.getDate();
  $('#wcG').innerHTML = WZ.map(([n, z]) => {
    const t = new Intl.DateTimeFormat('en-GB', { timeZone: z, hour: '2-digit', minute: '2-digit', hour12: false }).format(now), h = +t.slice(0, 2);
    const dd = +new Intl.DateTimeFormat('en-GB', { timeZone: z, day: 'numeric' }).format(now), df = dd === local ? 'Hari ini' : (dd > local || (dd === 1 && local > 27) ? 'Besok' : 'Kemarin');
    return `<div><span class="wci">${h >= 6 && h < 18 ? '☀️' : '🌙'}</span><div><b>${t}</b><small>${n} · ${df}</small></div></div>`;
  }).join('');
}
wcRender(); setInterval(() => { if (open) wcRender(); }, 5000);

const lvl = v => v > 85 ? '#fb7185' : v > 65 ? '#fbbf24' : '#34d399';
function syRender(d) {
  [['C', d.cpu], ['M', d.mem], ['D', d.disk]].forEach(([k, v]) => { const i = $('#sy' + k), t = $('#sy' + k + 'v'); if (v == null) { t.textContent = '--'; return; } i.style.transform = `scaleX(${v / 100})`; i.style.background = lvl(v); t.textContent = v + '%'; });
  const u = d.up, dd = Math.floor(u / 86400), hh = Math.floor(u % 86400 / 3600), mm = Math.floor(u % 3600 / 60);
  $('#syU').textContent = `RAM ${d.memGB} GB · menyala ${dd ? dd + 'h ' : ''}${hh}j ${mm}m` + (B.ok ? ` · baterai ${Math.round(B.level * 100)}%${B.charging ? ' ⚡' : ''}` : '');
}
setInterval(() => { if (open && cur === pg('System')) api.sys().then(syRender); }, 1500);
$$('.lc button').forEach(b => b.onclick = () => { api.launch(b.dataset.l); b.classList.remove('hit'); void b.offsetWidth; b.classList.add('hit'); flashTitle('Membuka ' + b.querySelector('small').textContent); });

const PEMO = { Music: '🎵', Ringkasan: '🗓️', Lyrics: '🎤', Weather: '⛅', Pomodoro: '🍅', Timer: '⏳', 'Water Reminder': '💧', 'To-do list': '✅', Notes: '📝', Calendar: '📅', 'World Clock': '🌍', Stopwatch: '⏱️', System: '📈', Clipboard: '📋', Launcher: '🚀', Game: '🎮', Shelf: '📥', Power: '⏻' };
const pm = $('#pmenu');
function buildMenu() { pm.innerHTML = ''; PAGES.forEach((p, i) => { const b = document.createElement('button'); b.className = 'pmi' + (i === cur ? ' on' : ''); b.style.setProperty('--i', i); b.innerHTML = `<span>${PEMO[p.n] || '•'}</span><small>${p.n}</small>`; b.onclick = () => { go(i); pm.classList.remove('show'); }; pm.appendChild(b); }); }
$('#pTitle').onclick = () => { buildMenu(); pm.classList.toggle('show'); };
/* ---------- start ---------- */
let lastSJ = '';
api.getSettings().then(s => { lastSJ = JSON.stringify(s); applySettings(s); frame(); });
api.onSettings(s => { lastSJ = JSON.stringify(s); applySettings(s); });
setInterval(() => api.getSettings().then(s => { const k = JSON.stringify(s); if (k !== lastSJ) { lastSJ = k; applySettings(s); } }), 2500);
api.getWeather().then(w => { if (w) { wx = w; renderWx(); applyMode(); } });
api.onWeather(w => { wx = w; renderWx(); applyMode(); });
tickClock(); setTimeout(() => { charAnim('a-jump', 750); burst(['♥', '✦'], 4, baseTheme[0]); }, 600);


/* ---------- v3: Ringkasan (menggantikan Music saat tidak ada musik), menu Game, pengingat istirahat ---------- */
function renderSum() {
  const n = new Date();
  $('#sDay').textContent = n.toLocaleDateString('id-ID', { weekday: 'long' });
  $('#sDate').textContent = n.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
  $('#sTodo').textContent = T.filter(t => t.d).length + '/' + T.length;
  $('#sWater').textContent = (W.ml / 1000).toFixed(1) + ' L';
  $('#sFocus').textContent = $('#pTime').textContent;
}
function syncMusicSlot() {
  const idle = !M.playing; MUSIC.n = idle ? 'Ringkasan' : 'Music';
  MUSIC.el.classList.toggle('idle', idle);
  if (PAGES[cur] === MUSIC) $('#pTitle').textContent = MUSIC.n;
  if (idle) renderSum();
}
let gmList = [];
async function loadGames() {
  const gl = $('#gl'), cnt = $('#gmN'); if (!gl) return;
  cnt.textContent = 'Memuat…';
  gmList = (await api.games()) || [];
  cnt.textContent = gmList.length ? gmList.length + ' game terdeteksi' : 'Belum ada game';
  gl.innerHTML = '';
  if (!gmList.length) { gl.innerHTML = '<div class="empty">Tidak ada game Steam / Epic yang terpasang</div>'; return; }
  gmList.forEach((g, i) => {
    const b = document.createElement('button'); b.className = 'gt'; b.dataset.i = i;
    const c = document.createElement('div'); c.className = 'gc' + (g.icon ? ' ic' : '');
    if (g.cover) c.style.backgroundImage = `url("${g.cover}")`; else c.innerHTML = `<span>${esc((g.name || '?').charAt(0).toUpperCase())}</span>`;
    const s = document.createElement('small'); s.textContent = g.name;
    b.append(c, s); gl.appendChild(b);
  });
}
$('#gl').addEventListener('click', e => {
  const b = e.target.closest('.gt'); if (!b) return; const g = gmList[+b.dataset.i]; if (!g) return;
  api.gameLaunch(g.id); flashTitle('Membuka ' + g.name); charAnim('a-jump', 700);
});
$('#gl').addEventListener('wheel', e => { e.currentTarget.scrollLeft += e.deltaY || e.deltaX; }, { passive: true });
$('#gmR').onclick = () => loadGames();
$('#pages').addEventListener('click', e => { const b = e.target.closest('[data-go]'); if (b) go(pg(b.dataset.go)); });

function tBreak(m) {
  return { type: 'break', mood: 'sleepy', w: 380, h: 52, ms: 7000, c: ['#818cf8', '#c084fc'], title: 'Istirahat dulu',
    fx: () => burst(['z', 'Z'], 3, '#93c5fd'),
    html: `<div class="tk"><div class="brk">💤</div><div class="txt"><b>Istirahat dulu yuk!</b><small>Sudah main ${m} menit. Regangkan badan & minum air.</small></div></div>` };
}
setInterval(() => { if (open && PAGES[cur] === MUSIC && !M.playing) renderSum(); }, 1000);
syncMusicSlot();
