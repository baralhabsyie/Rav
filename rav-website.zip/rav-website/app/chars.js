/* Rav characters — 7 karakter SVG original (Mochi Kitty = utama) */
(function () {
  const D = '#241338', f = n => +n.toFixed(2);
  function face(o) {
    const lx = o.lx ?? 14, rx = o.rx ?? 26, y = o.y ?? 18, r = o.r ?? 2.1, col = o.col ?? D, my = o.my ?? 23, mc = o.mc ?? col;
    const hi = o.hi === false ? '' : (o.hi || '#fff'), bl = o.blush === undefined ? '#ff8fb1' : o.blush, by = o.by ?? (y + 3.8);
    const eye = x => (o.shape === 'rect'
      ? `<rect x="${f(x - r)}" y="${f(y - r * 1.3)}" width="${f(r * 2)}" height="${f(r * 2.6)}" rx="${f(r * .55)}" fill="${col}"/>`
      : `<ellipse cx="${x}" cy="${y}" rx="${r}" ry="${f(r * 1.3)}" fill="${col}"/>`)
      + (hi ? `<circle cx="${f(x + r * .38)}" cy="${f(y - r * .55)}" r="${f(r * .38)}" fill="${hi}"/>` : '');
    const smile = o.smile || `M${20 - 2.4} ${my}q2.4 2.8 4.8 0`;
    const heart = x => `<path transform="translate(${x} ${f(y + .5)}) scale(1.4)" d="M0 1.6C-3.4-1.2-2-3.8 0-2.2 2-3.8 3.4-1.2 0 1.6z"/>`;
    return `<g class="look"><g class="ey">${eye(lx)}</g><g class="ey">${eye(rx)}</g></g>`
      + (bl ? `<g fill="${bl}" opacity=".5"><ellipse cx="${f(lx - 2.6)}" cy="${f(by)}" rx="2.3" ry="1.3"/><ellipse cx="${f(rx + 2.6)}" cy="${f(by)}" rx="2.3" ry="1.3"/></g>` : '')
      + `<g class="eh" fill="none" stroke="${col}" stroke-width="1.7" stroke-linecap="round"><path d="M${f(lx - 2.4)} ${f(y + 1)}q2.4 -3.8 4.8 0"/><path d="M${f(rx - 2.4)} ${f(y + 1)}q2.4 -3.8 4.8 0"/></g>`
      + `<g class="eheart" fill="#ff4d8d">${heart(lx)}${heart(rx)}</g>`
      + `<path class="ms" d="${smile}" fill="none" stroke="${mc}" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>`
      + `<g class="mo"><ellipse cx="20" cy="${f(my + 1.3)}" rx="2.3" ry="2.6" fill="${mc}"/>${o.tongue === false ? '' : `<ellipse cx="20" cy="${f(my + 2.6)}" rx="1.4" ry=".9" fill="#ff7a9c"/>`}</g>`
      + `<path class="mf" d="M${20 - 2.2} ${f(my + 2.6)}q2.2 -2.8 4.4 0" fill="none" stroke="${mc}" stroke-width="1.5" stroke-linecap="round"/>`
      + `<path class="mx" d="M${20 - 1.8} ${f(my + 1.2)}h3.6" fill="none" stroke="${mc}" stroke-width="1.5" stroke-linecap="round"/>`
      + `<path class="tear" d="M${f(lx - .2)} ${f(y + 2.6)}q-1.5 2.3 0 3.4q1.5 -1.1 0 -3.4zM${f(rx + .2)} ${f(y + 2.6)}q-1.5 2.3 0 3.4q1.5 -1.1 0 -3.4z" fill="#7dd3fc"/>`
      + `<path class="sweat" d="M32 7.5q-2.2 3.2 0 4.6q2.2 -1.4 0 -4.6z" fill="#7dd3fc"/>`;
  }
  const wrap = (id, inner) => `<svg class="chr ${id}" viewBox="0 0 40 32" xmlns="http://www.w3.org/2000/svg"><g class="all">${inner}</g></svg>`;

  const CHARS = {
    kitty: {
      name: 'Mochi Kitty', desc: 'Kucing mochi manis (utama)', c1: '#ff9a62', c2: '#ff6fae',
      svg: () => wrap('kitty',
        `<g class="ear-l"><path d="M5.5 14L6.5 2.5L16.5 8.5z" fill="#ffd9a8"/><path d="M8 11L8.4 6L12.6 8.8z" fill="#ff9ebb"/></g>
         <g class="ear-r"><path d="M34.5 14L33.5 2.5L23.5 8.5z" fill="#ffd9a8"/><path d="M32 11L31.6 6L27.4 8.8z" fill="#ff9ebb"/></g>
         <ellipse cx="20" cy="19" rx="15" ry="11.5" fill="#ffd9a8"/>
         <path d="M20 8.2v3M16.5 8.8l.8 2.4M23.5 8.8l-.8 2.4" stroke="#f4a96a" stroke-width="1.2" stroke-linecap="round"/>
         <g stroke="#d9a070" stroke-width=".8" stroke-linecap="round"><path d="M3.4 19.5l5 .8M3.6 23l5-1M36.6 19.5l-5 .8M36.4 23l-5-1"/></g>
         <path d="M18.8 21.1h2.4l-1.2 1.4z" fill="#ff7a9c"/>` +
        face({ lx: 13.5, rx: 26.5, y: 17.6, my: 23.4, by: 21.6, smile: 'M17.4 23.4q1.3 1.7 2.6 0q1.3 1.7 2.6 0' }))
    },
    ghost: {
      name: 'Boo Ghost', desc: 'Hantu mungil yang melayang', c1: '#a78bfa', c2: '#67e8f9',
      svg: () => wrap('ghost',
        `<ellipse class="arm-l" cx="4" cy="21" rx="2.8" ry="1.9" fill="#ede9fe"/><ellipse class="arm-r" cx="36" cy="21" rx="2.8" ry="1.9" fill="#ede9fe"/>
         <path d="M5 29V15C5 7.5 11 3.2 20 3.2S35 7.5 35 15V29l-5-3.4-5 3.4-5-3.4-5 3.4-5-3.4z" fill="#ede9fe"/>
         <path d="M8.5 12c1-3.6 4.6-6 8.6-6.4" stroke="#fff" stroke-width="1.7" stroke-linecap="round" fill="none"/>
         <path d="M7 26.5l3 2 5-3.4" stroke="#ddd6fe" stroke-width="1" fill="none" opacity=".6"/>` +
        face({ lx: 14, rx: 26, y: 15.4, my: 20.4, blush: '#f9a8d4', by: 19.2 }))
    },
    bunny: {
      name: 'Pochi Bunny', desc: 'Kelinci putih telinga panjang', c1: '#fb7185', c2: '#f0abfc',
      svg: () => wrap('bunny',
        `<g class="ear-l"><ellipse cx="12.5" cy="8.5" rx="3.6" ry="8" fill="#fff"/><ellipse cx="12.5" cy="9.2" rx="1.8" ry="5.3" fill="#ffb6c9"/></g>
         <g class="ear-r"><ellipse cx="27.5" cy="8.5" rx="3.6" ry="8" fill="#fff"/><ellipse cx="27.5" cy="9.2" rx="1.8" ry="5.3" fill="#ffb6c9"/></g>
         <ellipse cx="20" cy="22" rx="14" ry="9.8" fill="#fff"/>
         <ellipse cx="20" cy="23.9" rx="1.3" ry=".9" fill="#ff8fa8"/>` +
        face({ lx: 14, rx: 26, y: 20.6, my: 25.3, blush: '#ffb6c9', by: 24.2, smile: 'M17.8 25.3q1.1 1.4 2.2 0q1.1 1.4 2.2 0' }))
    },
    alien: {
      name: 'Zibo Alien', desc: 'Alien hijau dari galaksi lucu', c1: '#4ade80', c2: '#22d3ee',
      svg: () => wrap('alien',
        `<g class="ant"><path d="M20 9V4.4" stroke="#86efac" stroke-width="1.5" stroke-linecap="round"/><circle class="bulb" cx="20" cy="3.4" r="2.2" fill="#fde047"/></g>
         <path d="M20 8C30 8 35.5 13.5 35.5 20C35.5 26.5 28.5 30.5 20 30.5S4.5 26.5 4.5 20C4.5 13.5 10 8 20 8z" fill="#4ade80"/>
         <ellipse cx="13" cy="12.8" rx="3" ry="1.4" fill="#bbf7d0" opacity=".75" transform="rotate(-25 13 12.8)"/>` +
        face({ lx: 13.2, rx: 26.8, y: 19, r: 3, col: '#0b2a17', my: 25.4, mc: '#0b2a17', blush: '#15803d', by: 24, tongue: false }))
    },
    slime: {
      name: 'Jelly Slime', desc: 'Slime biru kenyal & imut', c1: '#38bdf8', c2: '#818cf8',
      svg: () => wrap('slime',
        `<path d="M20 9c-1.2-2.8-.6-4.6 1.2-6.2 1.2 2.2.8 4.4-1.2 6.2z" fill="#7dd3fc"/>
         <path d="M3.5 29.5C3.5 20 6.5 9 20 9S36.5 20 36.5 29.5c0 1.4-1 2-2.4 2H5.9c-1.4 0-2.4-.6-2.4-2z" fill="#38bdf8"/>
         <ellipse cx="11.5" cy="15.2" rx="3.2" ry="1.7" fill="#fff" opacity=".6" transform="rotate(-35 11.5 15.2)"/>
         <circle cx="27.5" cy="13" r=".9" fill="#fff" opacity=".6"/>` +
        face({ lx: 14, rx: 26, y: 21.2, my: 26, blush: '#f0abfc', by: 25 }))
    },
    robot: {
      name: 'Bolt Robot', desc: 'Robot mungil mata LED', c1: '#fbbf24', c2: '#38bdf8',
      svg: () => wrap('robot',
        `<g class="ant"><path d="M20 8V3.8" stroke="#cbd5e1" stroke-width="1.5" stroke-linecap="round"/><circle class="bulb" cx="20" cy="3" r="2.1" fill="#f87171"/></g>
         <rect class="arm-l" x="2.2" y="15" width="3.2" height="8" rx="1.6" fill="#94a3b8"/><rect class="arm-r" x="34.6" y="15" width="3.2" height="8" rx="1.6" fill="#94a3b8"/>
         <rect x="5" y="8" width="30" height="22" rx="8" fill="#cbd5e1"/>
         <rect x="8.5" y="11.5" width="23" height="15" rx="5.5" fill="#0f172a"/>` +
        face({ lx: 14.5, rx: 25.5, y: 17.4, r: 2, shape: 'rect', col: '#67e8f9', hi: false, my: 22.1, mc: '#67e8f9', blush: null, tongue: false, smile: 'M17.4 22.1q2.6 2.4 5.2 0' }))
    },
    bear: {
      name: 'Bruni Bear', desc: 'Beruang cokelat yang hangat', c1: '#fb923c', c2: '#f472b6',
      svg: () => wrap('bear',
        `<g class="ear-l"><circle cx="8" cy="9" r="5" fill="#c08457"/><circle cx="8" cy="9.4" r="2.6" fill="#f5c9a0"/></g>
         <g class="ear-r"><circle cx="32" cy="9" r="5" fill="#c08457"/><circle cx="32" cy="9.4" r="2.6" fill="#f5c9a0"/></g>
         <ellipse cx="20" cy="19.5" rx="15" ry="11.5" fill="#c08457"/>
         <ellipse cx="20" cy="23.2" rx="6.4" ry="4.6" fill="#f5d3b0"/>
         <ellipse cx="20" cy="21.2" rx="1.9" ry="1.3" fill="#3b2314"/>` +
        face({ lx: 13.2, rx: 26.8, y: 17.4, col: '#2a1608', my: 23.7, mc: '#3b2314', blush: '#fb7185', by: 21.4, smile: 'M17.9 23.7q2.1 2.4 4.2 0' }))
    }
  };
  window.CHARS = CHARS;
  window.CHAR_ORDER = ['kitty', 'ghost', 'bunny', 'alien', 'slime', 'robot', 'bear'];
})();
