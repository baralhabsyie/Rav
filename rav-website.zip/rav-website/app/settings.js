const api = window.rav, $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
let S = null, bigSvg = null, danceT = 0;
const root = document.documentElement;
const MOODS = [['', 'Normal'], ['happy', 'Senang 😄'], ['love', 'Jatuh cinta 😍'], ['sleepy', 'Ngantuk 😴'], ['scared', 'Takut 😰'], ['surprise', 'Kaget 😲'], ['sad', 'Sedih 😢'], ['dance', 'Joget 🎵']];
const ACTS = [['a-jump', 'Lompat'], ['a-wiggle', 'Goyang'], ['a-spin', 'Muter'], ['a-squish', 'Penyet'], ['a-look', 'Celingak-celinguk'], ['a-ears', 'Gerak telinga']];
const TESTS = [['play', '🎵 Play musik'], ['volup', '🔊 Volume naik'], ['voldown', '🔉 Volume turun'], ['dl', '⬇️ Download'], ['dldone', '✅ Download selesai'], ['copy', '📋 Copy'], ['paste', '📥 Paste'], ['plug', '⚡ Charger dicolok'], ['unplug', '🔌 Charger dicabut'], ['low', '🪫 Baterai 15%'], ['crit', '🚨 Baterai 5%'], ['rand', '🎲 Karakter acak'], ['gamebreak', '💤 Pengingat istirahat']];

function setTheme(c1, c2) { root.style.setProperty('--a1', c1); root.style.setProperty('--a2', c2); }
function act(svg, cls, ms) { svg.classList.remove(cls); void svg.getBoundingClientRect(); svg.classList.add(cls); setTimeout(() => svg.classList.remove(cls), ms); }
function mood(svg, m) {
  clearInterval(danceT); [...svg.classList].forEach(c => (c.startsWith('m-') || c === 'a-dance') && svg.classList.remove(c));
  if (m === 'dance') { svg.classList.add('m-happy', 'a-dance'); const t0 = performance.now(); danceT = setInterval(() => { const n = (performance.now() - t0) / 1000, b = Math.min(1, Math.pow(.5 + .5 * Math.sin(n * 11.9), 2) * .55 + .12 + .3 * (.5 + .5 * Math.sin(n * 19.5))); svg.style.setProperty('--b', b); svg.style.setProperty('--rot', Math.sin(n * 5.9) * 5); }, 30); }
  else if (m) svg.classList.add('m-' + m);
}
function renderStage() {
  const c = CHARS[S.character]; $('#big').innerHTML = c.svg(); bigSvg = $('#big .chr'); $('#sName').textContent = c.name; $('#sDesc').textContent = c.desc; setTheme(c.c1, c.c2);
  const m = $('#moods'); m.innerHTML = '';
  MOODS.forEach(([k, n]) => { const b = document.createElement('button'); b.className = 'chip' + (k === '' ? ' on' : ''); b.textContent = n; b.onclick = () => { $$('.chip', m).forEach(x => x.classList.remove('on')); b.classList.add('on'); mood(bigSvg, k); }; m.appendChild(b); });
  ACTS.forEach(([k, n]) => { const b = document.createElement('button'); b.className = 'chip'; b.textContent = n; b.onclick = () => act(bigSvg, k, 2300); m.appendChild(b); });
  $('#big').onclick = () => act(bigSvg, ACTS[Math.floor(Math.random() * 4)][0], 900);
}
function renderGrid() {
  const g = $('#grid'); g.innerHTML = '';
  CHAR_ORDER.forEach(id => {
    const c = CHARS[id], d = document.createElement('div'); d.className = 'cc' + (id === S.character ? ' on' : ''); d.style.setProperty('--c1', c.c1);
    d.innerHTML = `<div class="pv">${c.svg()}</div><b>${c.name}</b><small>${c.desc}</small>`;
    const sv = $('.chr', d);
    d.onmouseenter = () => { act(sv, ACTS[Math.floor(Math.random() * ACTS.length)][0], 1100); sv.classList.add('m-happy'); };
    d.onmouseleave = () => sv.classList.remove('m-happy');
    d.onclick = () => { api.setSettings({ character: id }); S.character = id; renderStage(); renderGrid(); act(bigSvg, 'a-jump', 800); mood(bigSvg, 'love'); setTimeout(() => mood(bigSvg, ''), 1600); };
    g.appendChild(d);
  });
}
const SHAPES = [['notch', 'Notch'], ['pill', 'Pil']];
const TINTS = [['black', 'Hitam'], ['tinted', 'Warna karakter'], ['ring', 'Garis neon']];
function renderShapes() {
  const g = $('#shapes'); g.innerHTML = '';
  SHAPES.forEach(([id, n]) => { const d = document.createElement('div'); d.className = 'shc' + (S.shape === id ? ' on' : ''); d.innerHTML = `<div class="sp sp-${id}"><i></i><span></span></div><b>${n}</b>`; d.onclick = () => { S.shape = id; api.setSettings({ shape: id }); renderShapes(); }; g.appendChild(d); });
  const t = $('#tints'); t.innerHTML = '';
  TINTS.forEach(([id, n]) => { const b = document.createElement('button'); b.className = 'chip' + (S.tint === id ? ' on' : ''); b.textContent = n; b.onclick = () => { S.tint = id; api.setSettings({ tint: id }); renderShapes(); }; t.appendChild(b); });
}
function sync() {
  renderShapes();
  $$('[data-k]').forEach(e => e.checked = !!S[e.dataset.k]); $$('[data-a]').forEach(e => e.checked = !!S.anim[e.dataset.a]);
  $('#gameMin').value = S.gameRemindMin || 60;
  $('#city').value = S.city || ''; $('#unit').value = S.unit; $('#freq').value = S.randomFreq; $('#ambL').value = S.ambientLevel; $('#ambV').textContent = S.ambientLevel + '%';
}
$$('[data-k]').forEach(e => e.onchange = () => { S[e.dataset.k] = e.checked; api.setSettings({ [e.dataset.k]: e.checked }); });
$$('[data-a]').forEach(e => e.onchange = () => { S.anim[e.dataset.a] = e.checked; api.setSettings({ anim: { [e.dataset.a]: e.checked } }); });
$('#freq').onchange = e => api.setSettings({ randomFreq: e.target.value });
$('#gameMin').onchange = e => api.setSettings({ gameRemindMin: +e.target.value });
$('#unit').onchange = e => api.setSettings({ unit: e.target.value });
$('#ambL').oninput = e => { $('#ambV').textContent = e.target.value + '%'; api.setSettings({ ambientLevel: +e.target.value }); };
$('#saveCity').onclick = () => { api.setSettings({ city: $('#city').value.trim(), unit: $('#unit').value }); $('#saveCity').textContent = 'Tersimpan ✓'; setTimeout(() => $('#saveCity').textContent = 'Simpan', 1500); };
TESTS.forEach(([k, n]) => { const b = document.createElement('button'); b.className = 'chip'; b.textContent = n; b.onclick = () => api.test(k); $('#tests').appendChild(b); });
document.addEventListener('mousemove', e => {
  $$('.chr').forEach(s => { const r = s.getBoundingClientRect(), dx = Math.max(-1, Math.min(1, (e.clientX - (r.left + r.width / 2)) / 260)), dy = Math.max(-1, Math.min(1, (e.clientY - (r.top + r.height / 2)) / 260)); s.style.setProperty('--ex', dx.toFixed(2)); s.style.setProperty('--ey', dy.toFixed(2)); });
});
function init(s) { const first = !S; S = s; if (first) { renderStage(); renderGrid(); } sync(); }
api.getSettings().then(init);
api.onSettings(s => { if (!S) return; const ch = s.character !== S.character; S = s; if (ch) { renderStage(); renderGrid(); } sync(); });
