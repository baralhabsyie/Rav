/* =========================================================
   Rav browser bridge
   Menggantikan preload.js (Electron) saat UI Rav dijalankan
   di dalam website. Semua panggilan window.rav dikirim ke
   halaman induk (hub.js), yang meniru peran main process.
   Nama fungsi & bentuk data sama persis dengan preload.js.
   ========================================================= */
(function () {
  if (window.rav || window.parent === window) return;

  const listeners = {};
  const pending = {};
  let seq = 0, ready = false;
  const queue = [];

  const raw = msg => window.parent.postMessage(Object.assign({ rav: 1 }, msg), '*');
  const flush = () => { ready = true; while (queue.length) raw(queue.shift()); };

  // handshake: keep saying hello until hub answers
  let tries = 0;
  const hello = setInterval(() => {
    if (ready || tries++ > 100) return clearInterval(hello);
    raw({ kind: 'hello' });
  }, 150);

  window.addEventListener('message', e => {
    const d = e.data;
    if (!d || d.rav !== 1) return;
    if (d.kind === 'ready') { clearInterval(hello); flush(); return; }
    if (d.kind === 'ret') {
      const p = pending[d.id];
      if (p) { delete pending[d.id]; p.resolve(d.value); }
      return;
    }
    if (d.kind === 'ev') {
      (listeners[d.ch] || []).forEach(cb => { try { cb(...d.args); } catch (err) { console.error(err); } });
    }
  });

  const send = (kind, fn) => (...args) => {
    const msg = { kind, fn, args };
    ready ? raw(msg) : queue.push(msg);
  };
  const call = fn => (...args) => new Promise(resolve => {
    const id = ++seq;
    pending[id] = { resolve };
    const msg = { kind: 'call', id, fn, args };
    ready ? raw(msg) : queue.push(msg);
  });
  const on = ch => cb => { (listeners[ch] = listeners[ch] || []).push(cb); };

  window.rav = {
    // events (main -> renderer)
    onState: on('state'),
    onCursor: on('cursor'),
    onMedia: on('media'),
    onAttention: on('attention'),
    onEvt: on('evt'),
    onSettings: on('settings'),
    onWeather: on('weather'),

    // renderer -> main, fire and forget
    mediaKey: send('send', 'mediaKey'),
    pin: send('send', 'pin'),
    attention: send('send', 'attention'),
    startDrag: send('send', 'startDrag'),
    openPath: send('send', 'openPath'),
    setSize: send('send', 'setSize'),
    power: send('send', 'power'),
    setVolume: send('send', 'setVolume'),
    volStep: send('send', 'volStep'),
    volMute: send('send', 'volMute'),
    launch: send('send', 'launch'),
    openSettings: send('send', 'openSettings'),
    test: send('send', 'test'),
    quit: send('send', 'quit'),
    gameLaunch: send('send', 'gameLaunch'),

    // renderer -> main, with reply
    getLyrics: call('getLyrics'),
    fileIcon: call('fileIcon'),
    getSettings: call('getSettings'),
    setSettings: call('setSettings'),
    getWeather: call('getWeather'),
    getVolume: call('getVolume'),
    sys: call('sys'),
    games: call('games'),

    // sinkron, tidak perlu IPC
    pathFor: () => ''
  };
})();
