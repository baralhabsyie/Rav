/* =========================================================
   RAV — landing page script
   ---------------------------------------------------------
   KONFIGURASI DOWNLOAD: ubah 'repo' ke akun GitHub kamu,
   lalu upload file installer ke GitHub Releases dengan nama
   yang sama seperti di bawah (lihat README.md).
   ========================================================= */
const RAV = {
  repo: 'baralhabsyie/rav',              // contoh: 'akbarhabsyie/rav'
  version: '3.0.0',
  installer: 'Rav-Setup-3.0.0.exe',  // nama file installer di Releases
  portable: 'Rav-3.0.0-portable.exe' // nama file versi portable di Releases
};
const releaseUrl = file => `https://github.com/${RAV.repo}/releases/latest/download/${file}`;

document.addEventListener('DOMContentLoaded', () => {

  /* ---------- download links ---------- */
  document.querySelectorAll('[data-download]').forEach(a => { a.href = releaseUrl(RAV.installer); a.setAttribute('download', RAV.installer); });
  document.querySelectorAll('[data-download-portable]').forEach(a => { a.href = releaseUrl(RAV.portable); a.setAttribute('download', RAV.portable); });

  const isWin = /Windows/i.test(navigator.userAgent);
  const note = document.getElementById('osNote');
  if (note) {
    note.innerHTML = isWin
      ? 'Terdeteksi Windows. Klik tombol di atas untuk mulai mengunduh.'
      : 'Rav hanya berjalan di Windows 10 / 11 (64-bit). Buka halaman ini di PC Windows untuk mengunduh.';
  }

  /* ---------- nav state ---------- */
  const nav = document.getElementById('nav');
  const onScroll = () => nav && nav.classList.toggle('scrolled', window.scrollY > 40);
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------- reveal on scroll ---------- */
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
  document.querySelectorAll('.reveal').forEach((el, i) => {
    // sedikit jeda berurutan untuk grup kartu di sekitar elemen yang sama
    const sib = el.parentElement ? [...el.parentElement.children].filter(c => c.classList.contains('reveal')) : [];
    const idx = Math.max(0, sib.indexOf(el));
    el.style.setProperty('--d', (Math.min(idx, 6) * 0.08) + 's');
    io.observe(el);
  });

  /* ---------- hero capsule cycling ---------- */
  const panels = document.querySelectorAll('#heroCap .cap-panel');
  const dots = document.querySelectorAll('#capDots i');
  let hi = 0;
  const showPanel = i => {
    panels.forEach((p, k) => p.classList.toggle('on', k === i));
    dots.forEach((d, k) => d.classList.toggle('on', k === i));
  };
  if (panels.length) {
    showPanel(0);
    setInterval(() => { hi = (hi + 1) % panels.length; showPanel(hi); }, 3200);
    dots.forEach((d, k) => d.addEventListener('click', () => { hi = k; showPanel(k); }));
  }

  /* ---------- feature card glow follows cursor ---------- */
  document.querySelectorAll('.feat').forEach(card => {
    card.addEventListener('pointermove', e => {
      const r = card.getBoundingClientRect();
      card.style.setProperty('--mx', (e.clientX - r.left) + 'px');
      card.style.setProperty('--my', (e.clientY - r.top) + 'px');
    });
  });

  /* ---------- guide tabs (panduan) ---------- */
  const tabs = document.querySelectorAll('.guide-tabs button');
  const gpanels = document.querySelectorAll('.guide-panel');
  tabs.forEach(t => t.addEventListener('click', () => {
    tabs.forEach(x => x.classList.toggle('on', x === t));
    gpanels.forEach(p => p.classList.toggle('on', p.id === t.dataset.target));
  }));

  /* ---------- toggles: hanya visual (contoh) ---------- */
  document.querySelectorAll('.toggles .tg').forEach(t => t.addEventListener('click', () => t.classList.toggle('on')));

  /* ---------- smooth anchor offset for fixed nav ---------- */
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const id = a.getAttribute('href');
      if (id.length < 2) return;
      const el = document.querySelector(id);
      if (el) { e.preventDefault(); el.scrollIntoView({ behavior: 'smooth', block: 'start' }); history.replaceState(null, '', id); }
    });
  });
});
